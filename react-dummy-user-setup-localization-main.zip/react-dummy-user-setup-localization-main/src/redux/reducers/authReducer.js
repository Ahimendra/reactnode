import { AuthActionTypes } from '../actions/AuthActions/actionType';
import storage from 'utils/storage';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const token = storage.get("legeteca_authToken", null);
const user = storage.get("legeteca_user", null);

export const initialState = {
    token: token,
    user: user,
    isloading: false,
    resetPasswordToken: null,
    authRedirectPath: '/'
}

const updateObject = (oldState, updatedProps) => {
    return {
        ...oldState,
        ...updatedProps
    }
}
const setUserData = (payload) => {
    console.log(">>>>>>>>>>>>>>>>>>>>>>",payload.data.token);
    storage.set('legeteca_user', payload.data._id);
    storage.set('legeteca_authToken', payload.data.token);
};
export const authReducer = (state = initialState, action) => {
    switch (action.type) {

        case AuthActionTypes.LOGIN_PENDING:
            return Object.assign({}, state, {
                isloading: true, disabled: true
            });
        case AuthActionTypes.LOGIN_FULFILLED:
            debugger
            setUserData(action.payload);
            return Object.assign({}, state, {
                isloading: false, disabled: false, user: action.payload.data._id, token: action.payload.data.token
            })

        //  case AuthActionTypes.REFRESH_TOKEN_FULFILLED:
        //      storage.set('legeteca_authToken', action.payload.token);
        //     return Object.assign({}, state, {
        //         isloading: false, disabled: false, token:  action.payload.token
        //     });

        case AuthActionTypes.SIGNUP_PENDING:
            return Object.assign({}, state, {
                isloading: true, disabled: true
            });
        case AuthActionTypes.SIGNUP_FULFILLED:
            setUserData(action.payload);
            return Object.assign({}, state, {
                isloading: false, disabled: false, user: action.payload.data.user, token:  action.payload.data.token
            });

       
        case AuthActionTypes.RESET_PASSWORD_PENDING:
            return Object.assign({}, state, { isloading: true, disabled: true });
        case AuthActionTypes.RESET_PASSWORD_FULFILLED:
            return Object.assign({}, state, { isloading: false, disabled: false });

        
        case AuthActionTypes.LOGOUT:
            return updateObject(state, {
                token: null,
                refresh_token: null,
                user: null,
                isloading: false,
                impersonate: false,
            });
            
        default: return state;
    }
}