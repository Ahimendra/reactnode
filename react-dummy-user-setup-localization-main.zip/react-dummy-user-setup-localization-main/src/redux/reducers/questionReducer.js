import { AuthActionTypes } from '../actions/QuestionsAction/actionType';
import storage from 'utils/storage';

export const initialState = {
    question: '',
    isloading: false
}

const setUserData = (payload) => {
    console.log(">>>>>>>>>>>>>>>>>>>>>>",payload.data.token);
    storage.set('legeteca_user', payload.data._id);
    storage.set('legeteca_authToken', payload.data.token);
};

export const authReducer = (state = initialState, action) => {
    switch (action.type) {

        case AuthActionTypes.GET_QUESTION_PENDING:
            return Object.assign({}, state, {
                isloading: true, disabled: true
            });
        case AuthActionTypes.GET_QUESTION_FULFILLED:
            debugger
            setUserData(action.payload);
            return Object.assign({}, state, {
                isloading: false, question: action.payload.data.data.question
            })

       
        case AuthActionTypes.CREATE_QUESTION_PENDING:
            return Object.assign({}, state, {
                isloading: true, disabled: true
            });
        case AuthActionTypes.CREATE_QUESTION_FULFILLED:
            setUserData(action.payload);
            return Object.assign({}, state, {
                isloading: false, question: action.payload.data.data.question
            });

       
        case AuthActionTypes.UPDATE_QUESTION_PENDING:
            return Object.assign({}, state, { isloading: true, disabled: true });
        case AuthActionTypes.UPDATE_QUESTION_FULFILLED:
            return Object.assign({}, state, { 
                isloading: false, question: action.payload.data.data.question
            });

        
        
            
        default: return state;
    }
}