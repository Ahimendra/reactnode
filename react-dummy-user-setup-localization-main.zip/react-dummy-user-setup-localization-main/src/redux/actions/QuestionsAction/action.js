//import axios from 'config';
import * as API from 'api/QuestionAPI';

import { UserActionTypes } from './actionType';

export const getQuestions = (params) => dispatch => dispatch({
    type: UserActionTypes.GET_QUESTION,
    payload: API.getQuestions(params)
});

export const createQuestion = (body) => dispatch => dispatch({
    type: UserActionTypes.CREATE_QUESTION,
    payload: API.createQuestion(body)
  });

export const updateQuestion = (body) => dispatch => dispatch({
  type: UserActionTypes.UPDATE_QUESTION,
  payload: API.updateQuestion(body)
});
