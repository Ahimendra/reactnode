//import axios from 'config';
import * as API from 'api/UserAPI';

import { UserActionTypes } from './actionType';

export const getUserById = (params) => dispatch => dispatch({
    type: UserActionTypes.GET_USER_BY_ID,
    payload: API.getUserById(params)
});

export const updateUser = (body) => dispatch => dispatch({
  type: UserActionTypes.UPDATE_USER,
  payload: API.updateUser(body)
});
