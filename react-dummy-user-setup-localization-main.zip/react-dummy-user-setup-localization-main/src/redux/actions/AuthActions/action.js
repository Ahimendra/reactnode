import axios from 'config';
import * as API from 'api';
import storage from 'utils/storage';

import { AuthActionTypes } from './actionType';


export const login = ({body}) => dispatch => {
    return dispatch({
        type: AuthActionTypes.LOGIN,
        payload: API.login(body).then(res => {
            console.log(":::::::::::::::::",res);
            axios.defaults.headers.common["Authorization"] = `Bearer ${res.token}`;
            return res
        }),
        
})

};

export const signup = ({body}) => dispatch => dispatch({
   type: AuthActionTypes.SIGNUP,
   payload: API.signup(body)
       .then(response => {
            axios.defaults.headers.common["Authorization"] = `Bearer ${response.data.token}`;
             return response;
       })
});
//


export const resetPassword = (body) => dispatch => dispatch({
   type: AuthActionTypes.RESET_PASSWORD,
   payload: API.resetPassword(body)
       .then(response => {
           return response
       })
});
export const refreshToken = (credentials) => dispatch => dispatch({
   type: AuthActionTypes.REFRESH_TOKEN,
   payload: API.refreshToken(credentials)
       .then(response => {
           axios.defaults.headers.common["Authorization"] = `Bearer ${response.token}`;
           return response
       })
});



export const logout = () => {

    storage.remove('legeteca_authToken');
    storage.remove('legeteca_user');
    //window.location.replace("/");
    return {
        type: AuthActionTypes.LOGOUT,
    }
};

