import { Route, Switch, withRouter, Redirect } from 'react-router-dom';

import CreateAccount from "./components/CreateAccount/CreateAccount";
import SignIn from 'components/SignIn/SignIn';


const App = () => {
  return (
    <div>
        <Switch>
          <Route path="/create-account" exact component={CreateAccount} />
          <Route path="/signin" component={SignIn} />
          <Redirect to="/create-account" />
        </Switch>
    </div>
  );
}

export default withRouter(App);
