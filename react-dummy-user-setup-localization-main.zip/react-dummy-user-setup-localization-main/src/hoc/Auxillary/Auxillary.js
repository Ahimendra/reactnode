const auxillary = props => props.children;

export default auxillary;