import { useState } from 'react';


const UseForm = validate =>{
    
    const[values, setValues] = useState({
        first_name: '',
        last_name: '',
        email: '',
        password: '',
        cpassword: '',
      });

    const[errors, setErrors] = useState({});

    const handleChange = e => {
        const { name, value } = e.target;
        setValues({
            ...values,
            [name]: value
        });
    };

    const handleSubmit = e => {
        debugger
        e.preventDefault();
        
        setErrors(validate(values));
    }

    return {handleChange, values, handleSubmit, errors};

};

export default UseForm;