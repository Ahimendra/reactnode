export default function validateInfo(values){
    let errors = {};

    //firstname
    if(!values.first_name.trim()){
        errors.first_name = "First-Name is required"
    }

    //lastname
    if(!values.last_name.trim()){
        errors.last_name = "Last-Name is required"
    }

    //email
    if(!values.email){
        errors.email = "Email Required"
    }else if (!/\S+@\S+\.\S+/.test(values.email)) {
        errors.email = 'Email address is invalid';
    }

    //password
    if(!values.password){
        errors.password = "Password is required"
    }else if(values.password.length < 6){
        errors.password = "Password needs to be 6 characters or more"
    }

    //confirmPassword
    if(!values.cpassword){
        errors.cpassword = "Password is required"
    }else if(values.cpassword !== values.password){
        errors.cpassword = "Password do not match"
    }

    return errors;

}