import React, { useContext } from "react";
import { NavLink } from "react-router-dom";
import { FormattedMessage } from "react-intl";

import { Context } from "components/SelectLanguages/WrapperComponent/WrapperComponent";
import "../css/custom.css";
import UseForm from "./useForm";
import validate from "./validateInfo";
import storage from "utils/storage";

const CreateAccount = () => {
  const { handleChange, values, handleSubmit, errors } = UseForm(validate);

  const context = useContext(Context);

  const changeLang = (lang) => {
    storage.set("lang", lang);
    context.selectLanguage(lang);
  };

  return (
    <React.Fragment>
      <article>
        <div className=" mt-1 mr-31" style={{ cursor: "pointer" }}>
          <strong
            className={context.locale == "hi" ? "logo_cc" : "logo_bb"}
            onClick={() => changeLang("hi")}
          >
            हिन्दी/
          </strong>
          <strong
            className={context.locale == "en" ? "logo_cc" : "logo_bb"}
            onClick={() => changeLang("en")}
          >
            English
          </strong>
        </div>
        <section className="sec-create-account">
          <div className="container">
            <h2 className="text-center">
              <FormattedMessage
                id="createAccount"
                defaultMessage="Create Account"
              />
            </h2>
            <form>
              <div className="row">
                <div className="col-12 col-md-6 col-sm-6 col-lg-6 col-xs-6 pr-4 pl-4">
                  <div className="form-group">
                    <label>
                      <FormattedMessage
                        id="firstName"
                        defaultMessage="First Name"
                      />
                    </label>
                    <div className="input-group mb-2">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <i className="fa fa-user"></i>
                        </div>
                      </div>
                      <FormattedMessage
                        id="firstName"
                        defaultMessage="First Name"
                      >
                        {(placeholder) => (
                          <input
                            id="firstName"
                            type="text"
                            className="form-control"
                            name="first_name"
                            placeholder={placeholder}
                            value={values.first_name}
                            onChange={handleChange}
                          />
                        )}
                      </FormattedMessage>
                      {errors.first_name && (
                        <span className="required">{errors.first_name}</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-6 col-sm-6 col-lg-6 col-xs-6 pr-4 pl-4">
                  <div className="form-group">
                    <label>
                      <FormattedMessage
                        id="lastName"
                        defaultMessage="Last Name"
                      />
                    </label>
                    <div className="input-group mb-2">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <i className="fa fa-user"></i>
                        </div>
                      </div>
                      <FormattedMessage
                        id="lastName"
                        defaultMessage="Last Name"
                      >
                        {(placeholder) => (
                          <input
                            id="lastName"
                            type="text"
                            className="form-control"
                            name="last_name"
                            placeholder={placeholder}
                            value={values.last_name}
                            onChange={handleChange}
                          />
                        )}
                      </FormattedMessage>
                      {errors.last_name && (
                        <span className="required">{errors.last_name}</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="col-12 pr-4 pl-4">
                  <div className="form-group">
                    <label>
                      <FormattedMessage id="email" defaultMessage="Email" />
                    </label>
                    <div className="input-group mb-2">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <i className="fas fa-envelope"></i>
                        </div>
                      </div>
                      <FormattedMessage id="email" defaultMessage="Email">
                        {(placeholder) => (
                          <input
                            id="email"
                            type="email"
                            className="form-control"
                            name="email"
                            placeholder={placeholder}
                            value={values.email}
                            onChange={handleChange}
                          />
                        )}
                      </FormattedMessage>
                      {errors.email && (
                        <span className="required">{errors.email}</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-6 col-sm-6 col-lg-6 col-xs-6 pr-4 pl-4">
                  <div className="form-group">
                    <label>
                      <FormattedMessage
                        id="password"
                        defaultMessage="Password"
                      />
                    </label>
                    <div className="input-group mb-2">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <i className="fas fa-unlock-alt"></i>
                        </div>
                      </div>
                      <FormattedMessage id="password" defaultMessage="Password">
                        {(placeholder) => (
                          <input
                            id="password"
                            type="password"
                            className="form-control"
                            name="password"
                            placeholder={placeholder}
                            value={values.password}
                            onChange={handleChange}
                          />
                        )}
                      </FormattedMessage>
                      {errors.password && (
                        <span className="required">{errors.password}</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-6 col-sm-6 col-lg-6 col-xs-6 pr-4 pl-4">
                  <div className="form-group">
                    <label>
                      <FormattedMessage
                        id="cpassword"
                        defaultMessage="Confirm Password"
                      />
                    </label>
                    <div className="input-group mb-2">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <i className="fas fa-unlock-alt"></i>
                        </div>
                      </div>
                      <FormattedMessage
                        id="cpassword"
                        defaultMessage="Confirm Password"
                      >
                        {(placeholder) => (
                          <input
                            id="confirmPassword"
                            type="password"
                            className="form-control"
                            name="cpassword"
                            placeholder={placeholder}
                            value={values.cpassword}
                            onChange={handleChange}
                          />
                        )}
                      </FormattedMessage>
                      {errors.cpassword && (
                        <span className="required">{errors.cpassword}</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="col-12 pr-4 pl-4">
                  <div className="form-group">
                    <button
                      type="button"
                      className="btn form-button"
                      onClick={(e) => {
                        handleSubmit(e);
                      }}
                    >
                      <FormattedMessage
                        id="createAccount"
                        defaultMessage="Create Account"
                      />
                    </button>
                  </div>
                </div>
              </div>
            </form>
            <div className="Or-line">
              <span>
                <FormattedMessage id="or" defaultMessage="Or" />
              </span>
            </div>
            <div className="text-center">
              <p>
                <FormattedMessage
                  id="alreadyAccount"
                  defaultMessage="Already have an account"
                />
                ?
                <NavLink to="/signin">
                  <FormattedMessage id="signin" defaultMessage="Sign In" />
                </NavLink>
              </p>
            </div>
          </div>
        </section>
      </article>
    </React.Fragment>
  );
};

export default CreateAccount;
