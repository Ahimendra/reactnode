import { useState, useEffect } from "react";
// import { useDispatch } from "react-redux";
// import { useHistory } from "react-router";
// import toastr  from 'toastr';

// import * as userAuthAction from "redux/actions/AuthActions";
// import { toast } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";
// import { forSuccess } from "utils/CommonService";

const UseForm = (validate) => {
  // const dispatch = useDispatch();

  // const history = useHistory();

  const [values, setValues] = useState({
    email: "",
    password: "",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    debugger;
    e.preventDefault();
    // dispatch(userAuthAction.login({ body: values }))
    //   .then((res) => {
    //     if (res.value.success) {
    //       toastr.success('We do have the Kapua suite available.', 'Turtle Bay Resort', {timeOut: 5000})
    //       history.push("/");
    //     }
    //   })
    //   .catch((err) => {
    //     toast.error("Username or Password is invalid", {
    //       position: toast.POSITION.TOP_RIGHT,
    //       autoClose: 10000,
    //     });
    //     console.log(err);
    //   });

    setErrors(validate(values));
  };

  return { handleChange, values, handleSubmit, errors };
};

export default UseForm;
