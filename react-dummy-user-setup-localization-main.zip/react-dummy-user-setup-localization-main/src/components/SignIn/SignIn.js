import React from "react";
// import { useSelector } from 'react-redux';
// import { ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
import { NavLink } from "react-router-dom";
import { FormattedMessage } from "react-intl";

import "../css/custom.css";
import UseForm from "./UseForm";
import validate from "./validationInfo";

const SignIn = (props) => {
  const { handleChange, values, handleSubmit, errors } = UseForm(validate);

  const Password = (
    <FormattedMessage
    id="password"
    defaultMessage="Password"
  >
    {(placeholder) => (
  
    <input
      id="password"
      type="password"
      className="form-control"
      name="password"
      placeholder={placeholder}
      value={values.password}
      onChange={handleChange}
      required
    />
    )}
    </FormattedMessage>
                      
  );

  return (
    <React.Fragment>
      <article>
        <section className="sec-create-account">
          <div className="container">
            <h2 className="text-center">
              <FormattedMessage id="signin" defaultMessage="Sign In" />
            </h2>
            <form>
              <div className="row">
                <div className="col-12 pr-4 pl-4">
                  <div className="form-group">
                    <div className="input-group mb-2">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <i className="fas fa-envelope"></i>
                        </div>
                      </div>
                      <FormattedMessage
                        id="enterYourEmail"
                        defaultMessage="First Name"
                      >
                        {(placeholder) => (
                      <input
                        id="email"
                        type="email"
                        className="form-control"
                        name="email"
                        placeholder={placeholder}
                        value={values.email}
                        onChange={handleChange}
                      />
                      )}
                      </FormattedMessage>
                      {errors.email && (
                        <span className="required">{errors.email}</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="col-12 pr-4 pl-4">
                  <div className="form-group">
                    <div className="input-group mb-2">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <i className="fas fa-unlock-alt"></i>
                        </div>
                      </div>
                      {Password}
                      {errors.password && (
                        <span className="required">{errors.password}</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="col-12 pr-4 pl-4">
                  <div className="form-group">
                    <button
                      type="button"
                      className="btn form-button"
                      onClick={(e) => {
                        handleSubmit(e);
                      }}
                    >
                     <FormattedMessage
                        id="signin"
                        defaultMessage="Sign In"
                      />
                    </button>
                  </div>
                </div>
              </div>
            </form>
            <div className="text-center">
              <p>
              <FormattedMessage
                        id="dontHaveAccount"
                        defaultMessage="Don't have an account?"
                      />
                <NavLink to="/create-account"><FormattedMessage
                                                id="createAccount"
                                                defaultMessage="Sign Up"
                                            />
                </NavLink>
              </p>
            </div>
          </div>
        </section>
      </article>
    </React.Fragment>
  );
};

export default SignIn;
