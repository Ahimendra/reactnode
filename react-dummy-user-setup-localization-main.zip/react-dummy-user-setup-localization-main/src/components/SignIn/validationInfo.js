export default function validateInfo(values){
    let errors = {};

    //email
    if(!values.email){
        errors.email = "Email Required"
    }else if (!/\S+@\S+\.\S+/.test(values.email)) {
        errors.email = 'Email address is invalid';
    }

    //password
    if(!values.password){
        errors.password = "Password is required"
    }

    return errors;

}