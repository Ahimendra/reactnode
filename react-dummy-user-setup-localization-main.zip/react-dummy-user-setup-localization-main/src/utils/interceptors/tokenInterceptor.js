export default function tokenInterceptor (response) {
	if (response.data.token) { }
	return response;
}