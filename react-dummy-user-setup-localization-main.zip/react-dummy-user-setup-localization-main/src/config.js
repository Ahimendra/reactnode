import axios from 'axios';
import storage from 'utils/storage';
import successHandler from "./utils/interceptors/successHandler";
import errorHandler from "./utils/interceptors/errorHandler";
import * as commonService from "utils/CommonService";
export const BASE_URL = () => {
  let url = 'http://167.71.228.49:3030/api';
  return url;
};


const instance = axios.create({
  baseURL: BASE_URL()
});
  instance.interceptors.request.use(config => {
  // show loader
  commonService.isLoading.onNext(true);
  return config;
});
instance.interceptors.response.use(config => {
  // hide loader
  commonService.isLoading.onNext(false);
  return config;
});
const token = storage.get("legeteca_authToken", null);
if (token) instance.defaults.headers.common["Authorization"] = `Bearer ${token}`;
instance.interceptors.response.use(
        response => successHandler(response),
        error => errorHandler(error)
);
export default instance;