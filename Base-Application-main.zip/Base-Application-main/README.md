How to use:
1. import sql file in common db
2. Unzip the UI code.
3. run "npm install"
4. npm start
5. Unzip the api code
6. run "npm install"
7. npm start
8. login with email: a@yopmail.com & password: password

